/* ═══════════════════════════════════════════════════════════════
 *  SOC-MAP v12 — AI 건물 검출 옵션 · 다시 분석 · 학습 데이터 수집
 *
 *  학습 데이터: 앱에서 확인·수정한 건물 외곽선을 정답으로 삼아 YOLO 세그멘테이션 형식으로 저장한다.
 *   - AI 서버가 켜져 있으면 backend/dataset/ 에 바로 누적 (train/val 자동 분할)
 *   - 꺼져 있으면 같은 구조의 ZIP 파일로 내려받는다
 * ═══════════════════════════════════════════════════════════════ */
'use strict';

const AI_OPTS_KEY = 'socmap.v12.aiopts';
const AI_DEFAULTS = { imgsz: 1024, tiling: 'auto', tta: false, enhance: false, regularize: true };
const AiOpts = (() => {
  try { return { ...AI_DEFAULTS, ...JSON.parse(localStorage.getItem(AI_OPTS_KEY) || '{}') }; } catch (e) { return { ...AI_DEFAULTS }; }
})();

function syncAiOptsUI() {
  $('optImgsz').value = AiOpts.imgsz;
  $('optTiling').value = AiOpts.tiling;
  $('optTta').checked = AiOpts.tta;
  $('optEnhance').checked = AiOpts.enhance;
  $('optRegularize').checked = AiOpts.regularize;
  const parts = [`${AiOpts.imgsz}px`, { auto: '타일 자동', on: '타일 항상', off: '타일 끔' }[AiOpts.tiling]];
  if (AiOpts.tta) parts.push('TTA');
  if (AiOpts.enhance) parts.push('보정');
  if (AiOpts.regularize) parts.push('직각');
  $('aiOptsSummary').textContent = parts.join(' · ');
}
function saveAiOpts() {
  try { localStorage.setItem(AI_OPTS_KEY, JSON.stringify(AiOpts)); } catch (e) { /* noop */ }
  syncAiOptsUI();
}
$('optImgsz').addEventListener('change', e => { AiOpts.imgsz = +e.target.value; saveAiOpts(); });
$('optTiling').addEventListener('change', e => { AiOpts.tiling = e.target.value; saveAiOpts(); });
$('optTta').addEventListener('change', e => { AiOpts.tta = e.target.checked; saveAiOpts(); });
$('optEnhance').addEventListener('change', e => { AiOpts.enhance = e.target.checked; saveAiOpts(); });
$('optRegularize').addEventListener('change', e => { AiOpts.regularize = e.target.checked; saveAiOpts(); });
$('optReset').addEventListener('click', () => { Object.assign(AiOpts, AI_DEFAULTS); saveAiOpts(); });

const dataUrlToBlob = async (src) => (await fetch(src)).blob();
const extOfMime = (mime) => ({ 'image/png': 'png', 'image/webp': 'webp', 'image/bmp': 'bmp' }[mime] || 'jpg');

/**
 * AI 검출 실행.
 * @param {Blob} blob  도면 이미지 원본
 * @param {{reset?: boolean}} opts  reset: 새 도면 업로드(히스토리 초기화) / 아니면 다시 분석(Ctrl+Z로 되돌리기 가능)
 */
async function runDetection(blob, filename, { reset = false } = {}) {
  const big = S.bgImage && Math.max(S.bgImage.naturalWidth, S.bgImage.naturalHeight) > AiOpts.imgsz * 1.5;
  const slow = AiOpts.tta || AiOpts.tiling === 'on' || (AiOpts.tiling === 'auto' && big);
  setLoading(`AI가 건축물을 분석하는 중…${slow ? '\n(타일 분할/TTA 사용 — 수 초~수십 초 걸릴 수 있습니다)' : ''}`);
  const form = new FormData();
  form.append('file', blob, filename || 'plan.jpg');
  form.append('imageType', document.querySelector('input[name="imageType"]:checked').value);
  form.append('conf', $('confSlider').value);
  form.append('imgsz', AiOpts.imgsz);
  form.append('tiling', AiOpts.tiling);
  form.append('tta', AiOpts.tta);
  form.append('enhance', AiOpts.enhance);
  try {
    const res = await fetch(BACKEND_URL + '/api/detect_buildings', { method: 'POST', body: form, signal: AbortSignal.timeout(300000) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.detail || `HTTP ${res.status}`);
    // AI 결과(도면 px) → 현장 좌표(m): 도면 정합 변환을 그대로 적용
    const T = planTransform() || makeTransform(defaultPlanTransform(S.plan.width, S.plan.height));
    S.contours = (data.contours || []).map(c => c.map(pt => { const q = Array.isArray(pt[0]) ? pt[0] : pt, w = T.apply({ x: +q[0], y: +q[1] }); return [[+w.x.toFixed(2), +w.y.toFixed(2)]]; }));
    S.nodes = (data.nodes || []).map(n => { const w = T.apply({ x: n.cx, y: n.cy }); return { ...n, cx: w.x, cy: w.y }; });
    S.buildingData = {}; S.selection = null;
    // 외곽선 직각 보정: 세그멘테이션 마스크의 울퉁불퉁한 외곽 → 실제 건물처럼 반듯한 다각형 (현장 m 좌표에서)
    let regular = 0;
    if (AiOpts.regularize) S.contours = S.contours.map(c => { const p = flattenContour(c), q = regularizeFootprint(p); if (q.length < p.length) regular++; return toContour(q); });
    const m = data.meta || {};
    const detail = [`${fmt((data.inference_ms || 0) / 1000, 1)}초`, `${m.imgsz || '?'}px`];
    if (regular) detail.push(`외곽선 ${regular}개 직각 보정`);
    if (m.tiles) detail.push(`타일 ${m.tiles}개`);
    if (m.raw_detections > S.contours.length) detail.push(`중복 ${m.raw_detections - S.contours.length}개 병합`);
    if (S.contours.length) {
      toast(`건축물 ${S.contours.length}개를 인식했습니다. (${detail.join(' · ')})\n틀린 외곽선은 지우거나 「🏢 건물 그리기」로 고친 뒤 「🎯 학습용 저장」하면 재학습에 쓸 수 있습니다.`, 'success', { duration: 7000 });
    } else {
      toast(`건축물을 찾지 못했습니다. (${detail.join(' · ')})\n처음 보는 도면 양식이면 「✨ AI 건물 따기」로 건물을 사각형으로 감싸 끌어 한 동씩 따세요.\n(신뢰도 임계값을 낮추거나 타일을 「항상」으로 두고 다시 분석해 볼 수도 있습니다)`, 'warn', { duration: 9000 });
    }
  } catch (err) {
    console.warn('AI 분석 실패', err);
    toast(`AI 분석에 실패했습니다: ${err.name === 'TimeoutError' ? '시간 초과' : err.message}\n도면은 정상 표시되며 수동으로 작업할 수 있습니다.`, 'error');
  } finally {
    setLoading(null);
    if (reset) History.init();
    changed(); renderModeUI(); renderInspector(); updateEmptyState();
  }
}

async function reanalyze() {
  if (!S.bgImageSrc) { toast('먼저 배치도 이미지를 불러오세요.', 'warn'); return; }
  if (!S.backendOnline) await checkBackend();
  if (!S.backendOnline) { toast('AI 서버가 꺼져 있어 분석할 수 없습니다.', 'error'); return; }
  const named = Object.values(S.buildingData).some(b => b && (b.name || b.entranceBlocked || b.floors));
  if (named && !confirm('다시 분석하면 건물 이름·층수·현관 통제 설정이 초기화됩니다. 계속할까요?\n(Ctrl+Z로 이전 결과를 되돌릴 수 있습니다)')) return;
  History.flush();
  await runDetection(await dataUrlToBlob(S.bgImageSrc), S.bgFileName || 'plan.jpg');
}

// ═══════════════════════════════════════════════
//  v14.7 AI 건물 따기 — 사각형(끌기)·점(누르기) → MobileSAM 외곽선 (backend/sam_inference.py)
//  학습한 YOLO 가 처음 보는 도면 양식에서 못 찾을 때(P1-2) 한 동씩 빠르게 지정
// ═══════════════════════════════════════════════
const AiPick = { src: null, id: null, busy: false };

/** @param {{point?: {x,y}, box?: [{x,y},{x,y}]}} prompt  현장 m 좌표
 *  배치도가 보이면 도면에서, 도면이 없거나 「배치도」를 끄면 위성 영상에서 딴다 (2026-11-22) */
async function aiPick(prompt) {
  if (AiPick.busy) return;
  if (!S.bgImageSrc || S.layers.bg === false) return aiPickMap(prompt);
  if (!S.backendOnline) await checkBackend();
  if (!S.backendOnline) { toast('AI 서버가 꺼져 있어 쓸 수 없습니다. 「🏢 건물」로 직접 그려 주세요.', 'error'); return; }
  const T = planTransform() || makeTransform(defaultPlanTransform(S.plan.width, S.plan.height));
  let field, value;
  if (prompt.point) { const q = T.inverse(prompt.point); field = 'point'; value = [+q.x.toFixed(1), +q.y.toFixed(1)]; }
  else {   // 현장에서 그린 사각형 → 도면 px 의 네 모서리 바깥 사각형 (도면이 회전돼 있어도)
    const [a, b] = prompt.box, cs = [{ x: a.x, y: a.y }, { x: b.x, y: a.y }, { x: b.x, y: b.y }, { x: a.x, y: b.y }].map(p => T.inverse(p));
    const xs = cs.map(p => p.x), ys = cs.map(p => p.y);
    field = 'box'; value = [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)].map(v => +v.toFixed(1));
  }
  const src = S.bgImageSrc;
  const send = async (withFile) => {
    const form = new FormData();
    if (withFile) form.append('file', await dataUrlToBlob(src), S.bgFileName || 'plan.jpg');
    else form.append('image_id', AiPick.id);
    form.append(field, JSON.stringify(value));
    const res = await fetch(BACKEND_URL + '/api/segment_building', { method: 'POST', body: form, signal: AbortSignal.timeout(90000) });
    return { res, data: await res.json().catch(() => ({})) };
  };
  AiPick.busy = true;
  $('hintText').textContent = '✨ AI가 외곽선을 따는 중…'; canvas.style.cursor = 'progress';
  try {
    const fresh = AiPick.src !== src || !AiPick.id;
    let { res, data } = await send(fresh);
    if (res.status === 404 && !fresh) ({ res, data } = await send(true));   // 서버를 다시 켜 도면이 없어졌으면 다시 올림
    if (!res.ok) throw new Error(data.detail || `HTTP ${res.status}`);
    AiPick.src = src; AiPick.id = data.image_id;
    if (S.bgImageSrc !== src) return;   // 기다리는 동안 도면이 바뀜
    if (!data.polygon) { toast(data.reason || '외곽선을 찾지 못했습니다.', 'warn', { duration: 6000 }); return; }
    const pts = [];
    for (const [x, y] of data.polygon) { const w = T.apply({ x, y }); pts.push(w.x, w.y); }
    await addPickedOutline(pts, data, field, '');
  } catch (err) {
    console.warn('AI 건물 따기 실패', err);
    toast(`AI 건물 따기에 실패했습니다: ${err.name === 'TimeoutError' ? '시간 초과' : err.message}`, 'error');
  } finally {
    AiPick.busy = false;
    $('hintText').textContent = (MODES.find(m => m.id === S.mode) || {}).hint || '';
    canvas.style.cursor = S.mode === 'select' ? 'default' : 'crosshair';
  }
}

/** 외곽선(현장 m)의 30 % 넘게가 공식 건물 외곽선 안인가 (브이월드 키가 없거나 조회 실패면 false) */
async function overlapsOfficialBuilding(pts, view) {
  if (!VWORLD.key || typeof fetchRealBuildings !== 'function') return false;
  try {
    const blds = await fetchRealBuildings(getFrame(), view);
    if (!blds.length) return false;
    const bb = polygonBBox(pts), st = 0.5;
    let n = 0, hit = 0;
    for (let x = bb.minX; x <= bb.maxX; x += st) for (let y = bb.minY; y <= bb.maxY; y += st) {
      if (!isPointInPolygon(x, y, pts)) continue;
      n++;
      if (blds.some(b => isPointInPolygon(x, y, b.poly))) hit++;
    }
    return n > 0 && hit / n >= 0.3;
  } catch (e) { return false; }
}

/** 2026-11-22 두 외곽선이 겹치는 넓이(m², 0.25 m 격자로 셈) */
function overlapArea(a, b) {
  const A = polygonBBox(a), B = polygonBBox(b);
  const x0 = Math.max(A.minX, B.minX), x1 = Math.min(A.maxX, B.maxX), y0 = Math.max(A.minY, B.minY), y1 = Math.min(A.maxY, B.maxY);
  if (x0 >= x1 || y0 >= y1) return 0;
  const st = 0.25;
  let n = 0;
  for (let x = x0 + st / 2; x < x1; x += st) for (let y = y0 + st / 2; y < y1; y += st) if (isPointInPolygon(x, y, a) && isPointInPolygon(x, y, b)) n++;
  return n * st * st;
}
/** 같은 건물로 볼 조건 (설계값): 겹침 0.5 m² 또는 작은 쪽 3 % 이상, 또는 1 m 안 틈으로 2 m 넘게 맞닿음(지붕 난간·줄눈 선) */
const MERGE = { GAP: 1.0, SHARED: 2.0, CLOSE: 0.6 };
/** a 둘레 가운데 b 에서 GAP 안에 있는 길이 (m) */
function sharedLength(a, b) {
  let L = 0;
  for (let i = 0, j = a.length - 2; i < a.length; j = i, i += 2) {
    const x0 = a[j], y0 = a[j + 1], x1 = a[i], y1 = a[i + 1], len = Math.hypot(x1 - x0, y1 - y0), n = Math.max(1, Math.ceil(len / 0.25));
    for (let k = 0; k < n; k++) { const t = (k + 0.5) / n; if (distanceToPolygon(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, b) <= MERGE.GAP) L += len / n; }
  }
  return L;
}
function belongTogether(a, b) {
  const A = polygonBBox(a), B = polygonBBox(b), g = MERGE.GAP;
  if (A.minX - B.maxX > g || B.minX - A.maxX > g || A.minY - B.maxY > g || B.minY - A.maxY > g) return false;
  const ov = overlapArea(a, b);
  if (ov >= 0.5 || ov >= 0.03 * Math.min(Math.abs(polygonArea(a)), Math.abs(polygonArea(b)))) return true;
  return Math.max(sharedLength(a, b), sharedLength(b, a)) >= MERGE.SHARED;
}
/** 새 외곽선과 겹치거나 붙은 기존 건물 번호 */
function overlappingBuildings(pts) {
  const out = [];
  getContourPolys().forEach((p, i) => { if (p && p.length >= 6 && belongTogether(pts, p)) out.push(i); });
  return out;
}
async function unionOnServer(polys) {
  const res = await fetch(BACKEND_URL + '/api/geom/union', { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ polys, close: MERGE.CLOSE }), signal: AbortSignal.timeout(20000) });
  const d = await res.json().catch(() => ({}));
  if (!res.ok || !d.polygon || d.polygon.length < 6) throw new Error(d.detail || `HTTP ${res.status}`);
  let q = d.polygon;
  if (AiOpts.regularize) { const r = regularizeFootprint(q); if (r.length >= 6) q = r; }
  return q;
}
/** 묶음마다 한 건물로 (extra: 첫 묶음에 더할 새 외곽선). 건물 정보는 가장 작은 번호 것을 두고 빈 칸만 채움, 출입구 점은 지우지 않음.
 *  서버가 못 합친 묶음은 그대로 둠. 반환: [{idx(새 번호), area, n}] */
async function mergeGroups(groups, extra) {
  const polys = getContourPolys(), done = [];
  for (let g = 0; g < groups.length; g++) {
    const list = groups[g].map(i => Array.from(polys[i]));
    if (g === 0 && extra) list.push(extra);
    if (list.length < 2) continue;
    try { done.push({ keep: Math.min(...groups[g]), drop: groups[g].filter(i => i !== Math.min(...groups[g])), q: await unionOnServer(list) }); }
    catch (e) { console.warn('합치지 못함', groups[g], e); if (g === 0 && extra) throw e; }
  }
  if (!done.length) return [];
  const dropAll = new Set(done.flatMap(r => r.drop)), byKeep = new Map(done.map(r => [r.keep, r]));
  const contours = [], nb = {}, newIdx = {};
  S.contours.forEach((c, i) => {
    if (dropAll.has(i)) return;
    const ni = contours.length; newIdx[i] = ni;
    const r = byKeep.get(i);
    if (r) {
      contours.push(toContour(r.q));
      const data = { ...(S.buildingData[i] || {}) };
      for (const j of r.drop) for (const [k, v] of Object.entries(S.buildingData[j] || {})) if (data[k] == null || data[k] === '') data[k] = v;
      if (Object.keys(data).length) nb[ni] = data;
    } else { contours.push(c); if (S.buildingData[i]) nb[ni] = S.buildingData[i]; }
  });
  S.contours = contours; S.buildingData = nb;
  return done.map(r => ({ idx: newIdx[r.keep], area: Math.abs(polygonArea(r.q)), n: r.drop.length + 1 }));
}
/** 이미 그려진 건물 가운데 겹치거나 붙은 것끼리 묶음 (연결된 것 전부) */
function touchingGroups(only = null) {
  const P = getContourPolys(), n = P.length, parent = [...Array(n).keys()];
  const find = (i) => (parent[i] === i ? i : (parent[i] = find(parent[i])));
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
    if (P[i] && P[j] && P[i].length >= 6 && P[j].length >= 6 && belongTogether(P[i], P[j])) parent[find(i)] = find(j);
  }
  const g = new Map();
  for (let i = 0; i < n; i++) { const r = find(i); if (!g.has(r)) g.set(r, []); g.get(r).push(i); }
  return [...g.values()].filter(x => x.length > 1 && (only == null || x.includes(only)));
}
/** 「🔗 겹치거나 붙은 조각 합치기」 — only: 그 건물이 낀 묶음만 */
async function mergeTouchingBuildings(only = null) {
  if (!S.backendOnline) await checkBackend();
  if (!S.backendOnline) { toast('서버가 꺼져 있어 합칠 수 없습니다.', 'error'); return; }
  const groups = touchingGroups(only);
  if (!groups.length) { toast(only == null ? '겹치거나 붙은 건물 조각이 없습니다.' : '이 건물과 겹치거나 붙은 조각이 없습니다.', 'info'); return; }
  History.flush();
  const res = await mergeGroups(groups);
  if (!res.length) { toast('합치지 못했습니다 (조각 사이가 1 m 넘게 떨어져 있음).', 'warn'); return; }
  changed(); renderModeUI(); updateEmptyState();
  select({ kind: 'building', idx: res[0].idx });
  toast(`조각 ${res.reduce((s, r) => s + r.n, 0)}개를 건물 ${res.length}개로 합쳤습니다 (Ctrl+Z 로 되돌리기)`, 'success', { duration: 5000 });
}

/** 딴 외곽선(현장 m) → 건물로 추가. 너무 작으면 버림. 기존 건물과 겹치면 한 건물로 합침 (2026-11-22) */
async function addPickedOutline(pts, data, field, note) {
  if (AiOpts.regularize) pts = regularizeFootprint(pts);
  const area = Math.abs(polygonArea(pts));
  if (pts.length < 6 || area < 4) { toast('너무 작은 영역이 잡혔습니다. 건물을 사각형으로 감싸듯 끌어 보세요.', 'warn'); return false; }
  const hits = overlappingBuildings(pts);
  if (hits.length) {
    try {
      const [m] = await mergeGroups([hits], pts);
      changed(); renderModeUI(); updateEmptyState();
      select({ kind: 'building', idx: m.idx });
      toast(`겹치거나 붙은 건물${hits.length > 1 ? ` ${hits.length}개` : ''}와 합쳐 한 건물로 만들었습니다${note} — ${fmt(m.area, 0)} m² (Ctrl+Z 로 되돌리기)`, 'success', { duration: 5000 });
      return true;
    } catch (e) {
      console.warn('외곽선 합치기 실패 — 따로 추가', e);
      note += ' · 겹치는 건물과 합치지 못해 따로 추가';
    }
  }
  S.contours = [...S.contours, toContour(pts)];   // 새 배열 (getContourPolys 캐시)
  changed(); renderModeUI(); updateEmptyState();
  select({ kind: 'building', idx: S.contours.length - 1 });
  toast(`외곽선을 땄습니다${note} — ${fmt(area, 0)} m² · ${fmt((data.ms || 0) / 1000, 1)}초${field === 'point' ? ' (일부만 잡혔으면 Ctrl+Z 후 사각형으로 끌기)' : ''}`, 'success', { duration: 5000 });
  return true;
}

// ═══════════════════════════════════════════════
//  2026-11-22 위성 지도에서 AI 건물 따기 — 도면 없이, 누른 곳 둘레의 위성 영상을 받아 MobileSAM 으로.
//  영상 px ↔ 현장 m 가 곧바로 대응하므로 도면 정합이 필요 없다. 영상 촬영 뒤 바뀐 건물은 다를 수 있다.
// ═══════════════════════════════════════════════
const MAP_PICK = {
  K: 4,          // 영상 해상도 4 px/m = 0.25 m/px (브이월드·Esri 줌 19 ≈ 0.24 m/px)
  HALF: 60,      // 점으로 누르면 사방 60 m (120 m 정사각형)
  PAD: 0.3,      // 사각형으로 끌면 30 % 여유 (최소 8 m)
  MAX_M: 300,    // 이보다 큰 사각형은 거절 (한 동씩)
  MAX_PX: 1800,  // 영상 한 변 최대
};
async function aiPickMap(prompt) {
  if (!getFrame()) { toast('현장 위치(📍)를 먼저 지정하세요. 위성 지도에서 따려면 현장 위치가 필요합니다. (프로젝트 메뉴 → 위치 · 주소 검색)', 'warn', { duration: 6000 }); return; }
  if (!S.backendOnline) await checkBackend();
  if (!S.backendOnline) { toast('AI 서버가 꺼져 있어 쓸 수 없습니다. 「🏢 건물」로 직접 그려 주세요.', 'error'); return; }
  let view;
  if (prompt.point) {
    const p = prompt.point, h = MAP_PICK.HALF;
    view = { minX: p.x - h, minY: p.y - h, maxX: p.x + h, maxY: p.y + h };
  } else {
    const [a, b] = prompt.box, w = Math.abs(b.x - a.x), hgt = Math.abs(b.y - a.y);
    if (Math.max(w, hgt) > MAP_PICK.MAX_M) { toast(`사각형이 너무 큽니다(${fmt(Math.max(w, hgt), 0)} m). 건물 한 동씩 감싸 주세요.`, 'warn'); return; }
    const pad = Math.max(8, MAP_PICK.PAD * Math.max(w, hgt));
    view = { minX: Math.min(a.x, b.x) - pad, minY: Math.min(a.y, b.y) - pad, maxX: Math.max(a.x, b.x) + pad, maxY: Math.max(a.y, b.y) + pad };
  }
  const k = Math.min(MAP_PICK.K, MAP_PICK.MAX_PX / Math.max(view.maxX - view.minX, view.maxY - view.minY));
  const toPx = (q) => [+((q.x - view.minX) * k).toFixed(1), +((q.y - view.minY) * k).toFixed(1)];
  const field = prompt.point ? 'point' : 'box';
  const value = prompt.point ? toPx(prompt.point) : (() => { const [a, b] = prompt.box, p1 = toPx({ x: Math.min(a.x, b.x), y: Math.min(a.y, b.y) }), p2 = toPx({ x: Math.max(a.x, b.x), y: Math.max(a.y, b.y) }); return [...p1, ...p2]; })();
  AiPick.busy = true;
  $('hintText').textContent = '🛰️ 위성 영상을 받는 중…'; canvas.style.cursor = 'progress';
  try {
    const cap = await Basemap.capture(view, k);
    if (cap.missing === cap.total) throw new Error('위성 영상을 받지 못했습니다 (인터넷 연결 확인)');
    let blob;
    try { blob = await new Promise((ok, bad) => cap.canvas.toBlob(b => (b ? ok(b) : bad(new Error('영상 만들기 실패'))), 'image/jpeg', 0.92)); }
    catch (e) { throw new Error('이 배경 지도는 영상 내보내기를 허용하지 않습니다. 배경을 「브이월드 영상」이나 「위성」으로 바꾸세요.'); }
    $('hintText').textContent = '✨ AI가 위성 영상에서 외곽선을 따는 중…';
    const form = new FormData();
    form.append('file', blob, 'satellite.jpg');
    form.append(field, JSON.stringify(value));
    form.append('source', 'satellite');   // 지붕 조각 합치기 · 주차장·도로 같은 바닥 판정 (sam_inference.segment_aerial)
    const res = await fetch(BACKEND_URL + '/api/segment_building', { method: 'POST', body: form, signal: AbortSignal.timeout(90000) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.detail || `HTTP ${res.status}`);
    const toWorld = (poly) => { const pts = []; for (const [x, y] of poly) pts.push(x / k + view.minX, y / k + view.minY); return pts; };
    const note = ` (${cap.source}${data.parts > 1 ? ` · 지붕 조각 ${data.parts}개를 한 건물로` : ''}${cap.missing ? ` · 영상 ${cap.missing}/${cap.total}칸 못 받음` : ''})`;
    if (!data.polygon && data.ground && data.fallback) {
      // 바닥 같다고 봤어도 공식 건물(브이월드 건물통합정보)과 30 % 넘게 겹치면 건물 — 분류기가 새 동네에서 건물을 바닥으로 볼 때가 있음
      const fb = toWorld(data.fallback);
      if (await overlapsOfficialBuilding(fb, view)) { await addPickedOutline(fb, data, field, `${note} · 공식 건물 정보와 겹쳐 건물로 판단`); return; }
      // 주차장·도로·잔디처럼 보임 — 바로 넣지 않고 묻는다 (공사 중 바닥판·옥상 주차장일 수도 있음)
      toast(`${data.reason} 건물이 맞으면 「그래도 추가」를 누르세요.`, 'warn', { duration: 10000,
        action: { label: '그래도 추가', fn: () => addPickedOutline(toWorld(data.fallback), data, field, `${note} · 바닥 같음 판정을 무시하고 추가`) } });
      return;
    }
    if (!data.polygon) { toast(data.reason || '외곽선을 찾지 못했습니다. 건물을 사각형으로 감싸듯 끌어 보세요.', 'warn', { duration: 6000 }); return; }
    await addPickedOutline(toWorld(data.polygon), data, field, note);
  } catch (err) {
    console.warn('위성 AI 건물 따기 실패', err);
    toast(`AI 건물 따기에 실패했습니다: ${err.name === 'TimeoutError' ? '시간 초과' : err.message}`, 'error', { duration: 6000 });
  } finally {
    AiPick.busy = false;
    $('hintText').textContent = (MODES.find(m => m.id === S.mode) || {}).hint || '';
    canvas.style.cursor = S.mode === 'select' ? 'default' : 'crosshair';
  }
}

// ═══════════════════════════════════════════════
//  학습 데이터 저장
// ═══════════════════════════════════════════════

/** 학습 라벨은 도면 이미지 기준이어야 하므로 현장 좌표(m) → 도면 px 로 되돌린다 */
function contoursInPlanPx() {
  const T = planTransform();
  return S.contours.map(c => flattenContour(c)).map(p => {
    const o = [];
    for (let i = 0; i < p.length; i += 2) { const q = T ? T.inverse({ x: p[i], y: p[i + 1] }) : { x: p[i], y: p[i + 1] }; o.push([+q.x.toFixed(1), +q.y.toFixed(1)]); }
    return o;
  });
}

function contoursToYoloText(contours, w, h) {
  return contours.map(c => {
    const p = c.flat();
    if (p.length < 6) return null;
    const v = [];
    for (let i = 0; i < p.length; i += 2) v.push(Math.min(1, Math.max(0, p[i] / w)).toFixed(6), Math.min(1, Math.max(0, p[i + 1] / h)).toFixed(6));
    return '0 ' + v.join(' ');
  }).filter(Boolean).join('\n');
}

async function refreshDatasetInfo() {
  if (!S.backendOnline) { $('datasetInfo').textContent = ''; return; }
  try {
    const st = await (await fetch(BACKEND_URL + '/api/dataset/stats', { signal: AbortSignal.timeout(3000) })).json();
    const total = st.train.images + st.val.images;
    $('datasetInfo').textContent = total
      ? `📚 모은 학습 데이터: 도면 ${total}장 (train ${st.train.images} · val ${st.val.images}) · 건물 ${st.train.buildings + st.val.buildings}개`
      : '';
  } catch (e) { $('datasetInfo').textContent = ''; }
}

async function saveTrainingSample() {
  if (!S.bgImageSrc) { toast('먼저 배치도 이미지를 불러오세요.', 'warn'); return; }
  if (!S.contours.length && !confirm('건물이 하나도 없는 도면으로 저장할까요?\n(건물이 없는 이미지도 오탐을 줄이는 학습 데이터가 됩니다)')) return;
  const blob = await dataUrlToBlob(S.bgImageSrc);
  const name = S.bgFileName || `plan.${extOfMime(blob.type)}`;

  if (!S.backendOnline) await checkBackend();
  if (S.backendOnline) {
    const form = new FormData();
    form.append('file', blob, name);
    form.append('contours', JSON.stringify(contoursInPlanPx()));
    try {
      const res = await fetch(BACKEND_URL + '/api/dataset/add', { method: 'POST', body: form, signal: AbortSignal.timeout(30000) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || res.status);
      toast(`학습 데이터로 저장했습니다 (${data.split}, 건물 ${data.buildings}개).\n누적: train ${data.stats.train.images}장 · val ${data.stats.val.images}장 — backend/dataset 폴더`, 'success', { duration: 6000 });
      refreshDatasetInfo();
      return;
    } catch (e) {
      toast(`서버 저장 실패: ${e.message}\nZIP 파일로 대신 내려받습니다.`, 'warn');
    }
  }

  // 오프라인: 같은 폴더 구조의 ZIP 으로 내려받기
  const iw = S.plan.width, ih = S.plan.height;
  const stem = name.replace(/\.[^.]+$/, '').replace(/[^0-9A-Za-z가-힣_-]+/g, '_').slice(0, 40) || 'plan';
  const tag = Date.now().toString(36);
  const files = [
    { name: `images/train/${stem}_${tag}.${extOfMime(blob.type)}`, data: new Uint8Array(await blob.arrayBuffer()) },
    { name: `labels/train/${stem}_${tag}.txt`, data: new TextEncoder().encode(contoursToYoloText(contoursInPlanPx(), iw, ih) + '\n') },
    { name: 'data.yaml', data: new TextEncoder().encode('path: .\ntrain: images/train\nval: images/val\nnames:\n  0: building\n') },
  ];
  const a = document.createElement('a');
  a.href = URL.createObjectURL(makeZip(files));
  a.download = `socmap-dataset_${stem}.zip`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  toast('AI 서버가 꺼져 있어 학습 데이터를 ZIP으로 내려받았습니다.\n압축을 풀어 backend/dataset 폴더에 합치세요. (일부는 images/val, labels/val 로 옮겨 검증용으로 쓰세요)', 'info', { duration: 8000 });
}

// ── 최소 ZIP 작성기 (무압축 STORE, 라이브러리 없이) ──
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
  return t;
})();
function crc32(buf) { let c = 0xFFFFFFFF; for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }

function makeZip(files) {
  const enc = new TextEncoder(), parts = [], central = [];
  let offset = 0;
  for (const f of files) {
    const name = enc.encode(f.name), crc = crc32(f.data), size = f.data.length;
    const local = new DataView(new ArrayBuffer(30));
    local.setUint32(0, 0x04034b50, true); local.setUint16(4, 20, true); local.setUint16(6, 0x0800, true); // UTF-8 파일명
    local.setUint32(14, crc, true); local.setUint32(18, size, true); local.setUint32(22, size, true); local.setUint16(26, name.length, true);
    parts.push(new Uint8Array(local.buffer), name, f.data);
    const cd = new DataView(new ArrayBuffer(46));
    cd.setUint32(0, 0x02014b50, true); cd.setUint16(4, 20, true); cd.setUint16(6, 20, true); cd.setUint16(8, 0x0800, true);
    cd.setUint32(16, crc, true); cd.setUint32(20, size, true); cd.setUint32(24, size, true); cd.setUint16(28, name.length, true);
    cd.setUint32(42, offset, true);
    central.push(new Uint8Array(cd.buffer), name);
    offset += 30 + name.length + size;
  }
  const cdSize = central.reduce((s, p) => s + p.length, 0);
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true);
  end.setUint32(12, cdSize, true); end.setUint32(16, offset, true);
  return new Blob([...parts, ...central, new Uint8Array(end.buffer)], { type: 'application/zip' });
}

$('reanalyzeBtn').addEventListener('click', reanalyze);
$('saveSampleBtn').addEventListener('click', saveTrainingSample);
$('aiAdvanced').addEventListener('toggle', refreshDatasetInfo);
syncAiOptsUI();
setTimeout(refreshDatasetInfo, 3000);
